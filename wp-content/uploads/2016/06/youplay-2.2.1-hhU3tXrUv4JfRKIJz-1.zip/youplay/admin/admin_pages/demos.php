<?php

$demos = array(
    'dark' => array(
        'preview' => 'http://wp.nkdev.info'
    ),
    'light' => array(
        'preview' => 'http://wp.nkdev.info'
    ),
    'black' => array(
        'preview' => 'http://wp.nkdev.info'
    )
);
add_thickbox();

if(!function_exists('nk_theme')) {
    ?>
    <p class="about-description">
        <mark class="error">
            <?php esc_html_e( 'You should install and activate required plugin nK Themes Helper. Find it in "Plugins" tab.', 'youplay' ); ?>
        </mark>
    </p>
    <?php
    return;
}

?>

<p class="about-description">
    <mark class="error"><?php esc_html_e( 'The included plugins in "Plugins" tab need to be installed and activated before you install a demo. Also open "Dashboard" tab and check that there are no notices in "Requirements" widget.', 'youplay' ); ?></mark>
    <br><br>
    <?php esc_html_e( 'Installing a demo provides images, pages, posts, theme options, widgets and more.', 'youplay' ); ?>
    <br><br>
    <?php esc_html_e( 'Please, wait before the process end. It may take a while.', 'youplay' ); ?>
</p>

<div class="nk-import-result"></div>

<div class="feature-section theme-browser nk-demos-list">
    <?php
    // Loop through all demos
    foreach ( $demos as $name => $demo ) { ?>
        <div class="theme">
            <div class="theme-wrapper">
                <div class="theme-screenshot">
                    <img src="<?php echo get_template_directory_uri() . '/admin/assets/images/demos/' . $name . '.png'; ?>" />
                </div>
                <h3 class="theme-name" id="<?php echo $name; ?>"><?php echo ucwords( str_replace( '_', ' ', $name ) ); ?></h3>
                <div class="theme-actions">
                    <?php printf( '<a class="button" target="_blank" href="%1s">%2s</a>', $demo['preview'], esc_html__( 'Preview', 'youplay' ) ); ?>
                    <?php printf( '<a class="button button-primary button-demo" data-demo="%s" href="#">%s</a>', strtolower( $name ), esc_html__( 'Install', 'youplay' ) ); ?>
                </div>
            </div>
        </div>
    <?php } ?>
</div>
