<?php
/**
 * Custom functions that act independently of the theme templates
 *
 * Eventually, some of the functionality here could be replaced by core features
 *
 * @package Youplay
 */

if ( ! function_exists( 'yp_sanitize_class' ) ) :
function yp_sanitize_class($classes) {
    if (!is_array($classes)) {
        $classes = explode(' ', $classes);
    }

    foreach($classes as $k => $v){
        $classes[$k] = sanitize_html_class($v);
    }

    return join(' ', $classes);

    return $classes;
}
endif;


/**
 * Fix Content for Shortcodes
 */
if ( ! function_exists( 'yp_fix_content' ) ) :
function yp_fix_content($content) {
    // fix for stupid </p> tag in start of string
    if (substr($content, 0, strlen("</p>")) == "</p>") {
        $content = substr($content, strlen("</p>"));
    }

    // fix for stupid <p> tag in end of string
    $content = preg_replace('/<p>$/', '', $content);

    // remove some <br> tags near shortcodes
    $content = str_replace( "]<br />","]", ( substr( $content, 0 , 6 ) == "<br />" ? substr( $content, 6 ): $content ) );

    // remove some <p> tags near shortcodes
    $content = str_replace( "]</p>","]", $content );
    $content = str_replace( "<p>[","[", $content );

    return $content;
}
endif;

/**
 * Get Rating HTML
 */
if ( ! function_exists( 'yp_get_rating' ) ) :
function yp_get_rating($rating) {
    if(( yp_check($rating) || $rating == 0) && is_numeric($rating)) {
        $rating_tmp = "";

        // ceil num
        $r_rating = ceil($rating/0.5)*0.5;

        for($k = 1; $k <= 5; $k++) {
            if($k <= $r_rating) {
                $rating_tmp .= ' <i class="fa fa-star"></i>';
            } else {
                if($k - 0.5 == $r_rating) {
                    $rating_tmp .= ' <i class="fa fa-star-half-o"></i>';
                } else {
                    $rating_tmp .= ' <i class="fa fa-star-o"></i>';
                }
            }
        }

        return '<div class="rating" data-rating="' . esc_attr($rating) . '">' . $rating_tmp . '</div>';
    } else {
        return "";
    }
}
endif;

/**
 * Get avatar URL
 * http://wordpress.stackexchange.com/questions/59442/how-do-i-get-the-avatar-url-instead-of-an-html-img-tag-when-using-get-avatar
 */
if ( ! function_exists( 'yp_get_avatar_url' ) ) :
function yp_get_avatar_url($get_avatar){
    preg_match("/src='(.*?)'/i", $get_avatar, $matches);
    return esc_url($matches[1]);
}
endif;

/* HEX to RGB colors */
/* http://bavotasan.com/2011/convert-hex-color-to-rgb-using-php/ */
if ( ! function_exists( 'hex2rgb' ) ) :
function hex2rgb($hex) {
   $hex = str_replace("#", "", $hex);

   if(strlen($hex) == 3) {
      $r = hexdec(substr($hex,0,1).substr($hex,0,1));
      $g = hexdec(substr($hex,1,1).substr($hex,1,1));
      $b = hexdec(substr($hex,2,1).substr($hex,2,1));
   } else {
      $r = hexdec(substr($hex,0,2));
      $g = hexdec(substr($hex,2,2));
      $b = hexdec(substr($hex,4,2));
   }
   $rgb = array($r, $g, $b);
   //return implode(",", $rgb); // returns the rgb values separated by commas
   return $rgb; // returns an array with the rgb values
}
endif;

/**
 * Maintenance Mode
 */
if ( ! function_exists( 'youplay_is_maintenance' ) ) :
function youplay_is_maintenance() {
    $maintenance = yp_opts('maintenance');
    $except_admin = yp_opts('maintenance_except_admin');

    if($maintenance && $except_admin && (is_admin() || is_super_admin())) {
        $maintenance = false;
    }
    return $maintenance;
}
endif;

add_action( 'template_redirect', 'youplay_maintenance_redirect' );
if ( ! function_exists( 'youplay_maintenance_redirect' ) ) :
function youplay_maintenance_redirect() {
  if (youplay_is_maintenance()) {
    require get_template_directory() . '/maintenance.php';
    exit();
  }
}
endif;

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
if ( ! function_exists( 'youplay_body_classes' ) ) :
function youplay_body_classes( $classes ) {
  // Adds a class of group-blog to blogs with more than 1 published author.
  if ( is_multi_author() ) {
    $classes[] = 'group-blog';
  }

  foreach($classes as $key => $class) {
      if($class == 'date') {
          $classes[$key] = 'archive-date';
      }
  }

  return $classes;
}
endif;
add_filter( 'body_class', 'youplay_body_classes' );


/**
 * Title Tag filter for 404
 */
add_filter( 'wp_title', 'yp_title', 10, 2 );
if ( ! function_exists( 'yp_title' ) ) :
function yp_title( $title ) {
    if( is_404() ) {
        $title = yp_opts('404_title');
    }
    return $title;
}
endif;


/**
 * Add 'full' to sizes list
 */
add_filter( 'intermediate_image_sizes', 'yp_intermediate_image_sizes' );
if ( ! function_exists( 'yp_intermediate_image_sizes' ) ) :
function yp_intermediate_image_sizes( $sizes ) {
    $sizes[] = 'full';
    return $sizes;
}
endif;


/**
 * Remove admin bar top margin
 */
add_action('get_header', 'remove_admin_login_header');
if ( ! function_exists( 'remove_admin_login_header' ) ) :
function remove_admin_login_header() {
    remove_action('wp_head', '_admin_bar_bump_cb');
}
endif;


/**
 * Add active classname for menu item
 */
add_filter('nav_menu_css_class' , 'special_nav_class' , 10 , 2);
if ( ! function_exists( 'special_nav_class' ) ) :
function special_nav_class($classes, $item){
     if( in_array('current-menu-item', $classes) || in_array('current-menu-ancestor', $classes) ){
          $classes[] = 'active ';
     }
     return $classes;
}
endif;


/**
 * Responsive video embed
 */
add_filter( 'embed_oembed_html', 'yp_oembed_filter', 10, 4 );
if ( ! function_exists( 'yp_oembed_filter' ) ) :
function yp_oembed_filter($html, $url, $attr, $post_ID) {
    $classes = '';
    if (strpos($url, 'youtube') > 0 || strpos($url, 'youtu.be') > 0) {
        $classes .= ' responsive-embed responsive-embed-16x9 embed-youtube';
    } else if (strpos($url, 'vimeo') > 0) {
        $classes .= ' responsive-embed responsive-embed-16x9 embed-vimeo';
    } else if (strpos($url, 'twitter') > 0) {
        $classes .= ' embed-twitter';
    }

    $return = '<div class="' . yp_sanitize_class($classes) . '">' . $html . '</div>';
    return $return;
}
endif;


/**
 * Open Graph Meta
 */
if ( ! function_exists( 'youplay_print_open_graph_meta' ) ) :
function youplay_print_open_graph_meta() {
    // check if option enabled
    if(!yp_opts('seo_enable')) {
        return;
    }

    // prevent Open graph data on Members page
    if ( class_exists('buddypress') && bp_current_component('members') ) {
        return;
    }

    $url = '';
    $title = '';
    $descr = '';
    $site_name = get_bloginfo('name');
    $image = '';

    if (is_home()) {
        $url = esc_url(home_url('/'));
    } else {
        $url = get_permalink();
        $title = get_the_title();
        $descr = apply_filters( 'the_excerpt', get_the_excerpt() );

        if (has_post_thumbnail()) {
            $image = wp_get_attachment_image_src( get_post_thumbnail_id(), 'Full');
            $image = $image[0];
        }
    }

    // use logo if there is no image
    if(!$image) {
        $image = yp_opts('general_logo');
    }

    // use blog info if there is no description
    if(!$descr) {
        $descr = get_bloginfo('description');
    }

    // use blog name if there is no title
    if(!$title) {
        $title = $site_name;
    }

    ?>

    <!-- Open Graph Meta -->
    <meta property="og:url" content="<?php echo esc_url($url); ?>" />
    <meta property="og:title" content="<?php echo wp_kses($title, array()); ?>" />
    <meta property="og:description" content="<?php echo wp_kses_data($descr, array()); ?>" />
    <meta property="og:site_name" content="<?php echo wp_kses($site_name, array()); ?>" />
    <meta property="og:image" content="<?php echo esc_url($image); ?>" />

    <meta itemprop="description" content="<?php echo wp_kses($descr, array()); ?>" />
    <meta itemprop="image" content="<?php echo esc_url($image); ?>" />

    <?php
}
endif;

/**
 * Get all terms for autocomplete visual composer selects and for post shortcodes
 */
if ( ! function_exists( 'yp_get_terms' ) ) :
function yp_get_terms() {
  $terms_list_vc = array();
  $terms_list = get_terms( get_object_taxonomies( get_post_types( array(
    'public' => false,
    'name' => 'attachment',
  ), 'names', 'NOT' ) ) );
  foreach($terms_list as $term) {
    $terms_list_vc[] = array(
      "value" => $term->term_id,
      "label" => $term->name,
      "group" => $term->taxonomy
    );
  }

  return $terms_list_vc;
}
endif;
