<?php

/**
 * No Search Results Feedback Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<div class="alert">
	<?php _e( 'Oh bother! No search results were found here!', 'youplay' ); ?>
</div>
