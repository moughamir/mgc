<?php

/**
 * No Topics Feedback Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<div class="alert">
	<?php _e( 'Oh bother! No topics were found here!', 'youplay' ); ?>
</div>
