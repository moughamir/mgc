<?php

require $this->admin_path . '/widgets/recent-posts.php';
require $this->admin_path . '/widgets/twitter.php';
require $this->admin_path . '/widgets/instagram.php';
