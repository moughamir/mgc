<?php
// Importer AJAX Action
add_action('wp_ajax_nk_demo_import_action', 'nk_demo_import_action');
function nk_demo_import_action () {
    if(!current_user_can('manage_options') || !function_exists('nk_theme')) {
        return;
    }

    $demo_name = 'dark';
    if (isset($_POST['demo_name']) && trim($_POST['demo_name']) != '') {
        $demo_name = $_POST['demo_name'];
    }

    $demo_path = nk_admin()->admin_path . '/demos/' . $demo_name;
    $import_data_file = $demo_path . '/content.xml';
    $import_widgets_file = $demo_path . '/widgets.json';
    $import_options_file = $demo_path . '/theme_options.txt';
    $main_page_title = 'Main';

    // remove old menus
    $delete_menus = wp_get_nav_menus();
    foreach ($delete_menus as $delete_menu) {
        if (is_nav_menu($delete_menu->term_id)) {
            wp_delete_nav_menu($delete_menu->term_id);
        }
    }

    // import all demo data
    echo '<br><h4>Demo Data:</h4>';
    nk_theme()->demo_importer()->import_demo_data($import_data_file);

    // setup widgets
    echo '<br><h4>Widgets:</h4>';
    nk_theme()->demo_importer()->import_demo_widgets($import_widgets_file);

    // options tree importer
    echo '<br><h4>Theme Options:</h4>';
    nk_theme()->demo_importer()->import_demo_options_tree($import_options_file);

    // setup menus
    $locations = get_theme_mod('nav_menu_locations');
    $menus = wp_get_nav_menus();
    if ($menus) {
        echo '<br><h4>Menus:</h4>';
        foreach($menus as $menu) {
            switch($menu->name) {
                case 'Main Menu':
                    $locations['primary'] = $menu->term_id;
                    echo '<p>Added menu: ' . $menu->name . '</p>';
                    break;
                case 'Right Menu':
                    $locations['primary-right'] = $menu->term_id;
                    echo '<p>Added menu: ' . $menu->name . '</p>';
                    break;
            }
        }
    }
    set_theme_mod('nav_menu_locations', $locations);

    // change some settings
    // permalink
    global $wp_rewrite;
    $wp_rewrite->set_permalink_structure( '/%postname%/' );

    // home page
    $homepage = get_page_by_title($main_page_title);
    if (isset($homepage) && $homepage->ID) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $homepage->ID);
    }

    die();
}
