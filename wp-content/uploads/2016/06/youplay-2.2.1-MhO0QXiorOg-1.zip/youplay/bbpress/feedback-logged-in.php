<?php

/**
 * Logged In Feedback Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<div class="alert">
	<?php _e( 'You are already logged in.', 'youplay' ); ?>
</div>
